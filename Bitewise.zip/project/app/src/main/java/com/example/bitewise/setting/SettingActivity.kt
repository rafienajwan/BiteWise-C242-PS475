package com.example.bitewise.setting

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bitewise.ui.theme.BitewiseTheme
import com.example.bitewise.user.UserViewModel
import com.example.bitewise.MainActivity

class SettingActivity : ComponentActivity() {

    private val userViewModel: UserViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BitewiseTheme {
                SettingScreen(
                    userViewModel = userViewModel,
                    onBackClicked = {
                        startActivity(Intent(this, MainActivity::class.java))
                        finish()
                    }
                )
            }
        }
    }

    @Composable
    fun SettingScreen(userViewModel: UserViewModel, onBackClicked: () -> Unit) {
        val userData by userViewModel.userData.collectAsState()

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Settings", fontWeight = FontWeight.Bold, fontSize = 20.sp) },
                    navigationIcon = {
                        IconButton(onClick = onBackClicked) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    },
                    backgroundColor = Color(0xFF35CC8C),
                    contentColor = Color.White,
                    elevation = 4.dp
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                SettingItem(
                    label = "Target Weight",
                    value = "${userData.target} kg",
                    onEditClicked = { newValue -> userViewModel.updateTarget(newValue.toInt()) }
                )
                SettingItem(
                    label = "Goal",
                    value = userData.goal,
                    isOption = true,
                    options = listOf("Maintain Weight", "Lose Weight", "Gain Weight"),
                    onEditClicked = { newValue -> userViewModel.updateGoal(newValue) }
                )
                SettingItem(
                    label = "Lifestyle",
                    value = userData.lifestyle,
                    isOption = true,
                    options = listOf("Sedentary", "Lightly Active", "Average", "Moderately Active", "Very Active"),
                    onEditClicked = { newValue -> userViewModel.updateLifestyle(newValue) }
                )
                SettingItem(
                    label = "Weight",
                    value = "${userData.weight} kg",
                    onEditClicked = { newValue -> userViewModel.updateWeight(newValue.toInt()) }
                )
            }
        }
    }

    @Composable
    fun SettingItem(
        label: String,
        value: String,
        isOption: Boolean = false,
        options: List<String> = emptyList(),
        onEditClicked: (String) -> Unit
    ) {
        var isDialogOpen by remember { mutableStateOf(false) }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { isDialogOpen = true }
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontWeight = FontWeight.Medium)
            Text(value, fontWeight = FontWeight.Light)
        }

        if (isDialogOpen) {
            if (isOption) {
                // Dialog untuk pilihan (dropdown)
                OptionDialog(
                    label = label,
                    options = options,
                    selectedValue = value,
                    onDismissRequest = { isDialogOpen = false },
                    onSaveClicked = { newValue ->
                        onEditClicked(newValue)
                        isDialogOpen = false
                    }
                )
            } else {
                // Dialog untuk input teks
                SettingItemDialog(
                    label = label,
                    value = value,
                    onValueChange = { newValue -> onEditClicked(newValue) },
                    onDismissRequest = { isDialogOpen = false },
                    onSaveClicked = { isDialogOpen = false }
                )
            }
        }
    }

    @Composable
    fun SettingItemDialog(
        label: String,
        value: String,
        onValueChange: (String) -> Unit,
        onDismissRequest: () -> Unit,
        onSaveClicked: () -> Unit
    ) {
        var newValue by remember { mutableStateOf(value) }

        AlertDialog(
            onDismissRequest = onDismissRequest,
            title = { Text("Edit $label") },
            text = {
                TextField(
                    value = newValue,
                    onValueChange = { newValue = it },
                    singleLine = true,
                    label = { Text(label) },
                    colors = TextFieldDefaults.textFieldColors(
                        focusedIndicatorColor = Color(0xFF35CC8C),
                        cursorColor = Color(0xFF35CC8C)
                    )
                )
            },
            confirmButton = {
                Button(onClick = {
                    onValueChange(newValue)
                    onSaveClicked()
                }, colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF35CC8C))) {
                    Text("Save", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissRequest) {
                    Text("Cancel", color = Color(0xFF35CC8C))
                }
            }
        )
    }

    @Composable
    fun OptionDialog(
        label: String,
        options: List<String>,
        selectedValue: String,
        onDismissRequest: () -> Unit,
        onSaveClicked: (String) -> Unit
    ) {
        var selectedOption by remember { mutableStateOf(selectedValue) }

        AlertDialog(
            onDismissRequest = onDismissRequest,
            title = { Text("Select $label") },
            text = {
                Column {
                    options.forEach { option ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedOption = option }
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(option)
                            if (selectedOption == option) {
                                Icon(Icons.Default.Check, contentDescription = "Selected")
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { onSaveClicked(selectedOption) }, colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF35CC8C))) {
                    Text("Save", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissRequest) {
                    Text("Cancel", color = Color(0xFF35CC8C))
                }
            }
        )
    }
}
