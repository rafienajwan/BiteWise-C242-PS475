package com.example.bitewise.burger

class SettingActivity {
}