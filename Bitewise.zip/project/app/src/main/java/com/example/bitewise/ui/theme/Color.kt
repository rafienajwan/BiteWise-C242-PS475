package com.example.bitewise.ui.theme

import androidx.compose.ui.graphics.Color

val colorPrimary = Color(0xFF35CC8C)
val colorOnPrimary = Color(0xFFFFFFFF)
val colorSecondary = Color(0xFF03DAC6)
val colorOnSecondary = Color(0xFF000000)
val colorBackground = Color(0xFFFFFFFF)
val colorOnBackground = Color(0xFF000000)
val colorSurface = Color(0xFFFFFFFF)
val colorOnSurface = Color(0xFF000000)
val colorError = Color(0xFFB00020)
val colorOnError = Color(0xFFFFFFFF)
