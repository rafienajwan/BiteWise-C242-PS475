package com.example.bitewise.food

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.bitewise.models.FoodItem

class FoodModel : ViewModel() {
    var searchQuery by mutableStateOf("")
        private set

    val allFoods: List<FoodItem> = listOf(
        FoodItem("Egg", 70, 6, 5, 0),
        FoodItem("Chicken Breast", 165, 31, 3, 0),
        FoodItem("Tofu", 80, 8, 4, 2),
        FoodItem("Salmon", 200, 22, 12, 0),
        FoodItem("Beef", 250, 22, 20, 0),
        FoodItem("Lentils", 120, 9, 0, 20),
        FoodItem("Chickpeas", 135, 9, 2, 25),
        FoodItem("Spinach", 23, 2, 0, 4),
        FoodItem("Carrot", 40, 1, 0, 9),
        FoodItem("Tomato", 22, 1, 0, 5),
    )

    val filteredFoods: List<FoodItem>
        get() = allFoods.filter { food -> food.name.contains(searchQuery, ignoreCase = true) }

    fun updateSearchQuery(query: String) {
        searchQuery = query
    }
}
