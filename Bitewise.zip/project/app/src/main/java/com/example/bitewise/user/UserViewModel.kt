package com.example.bitewise.user

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore

private val USER_PREFERENCES = "user_preferences"

// DataStore key definitions
private val KEY_GOAL = stringPreferencesKey("goal")
private val KEY_AGE = intPreferencesKey("age")
private val KEY_WEIGHT = intPreferencesKey("weight")
private val KEY_TARGET = intPreferencesKey("target")
private val KEY_LIFESTYLE = stringPreferencesKey("lifestyle")

// Extend Application context for DataStore
val Application.dataStore by preferencesDataStore(name = USER_PREFERENCES)

class UserViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application

    // State to observe in Composables
    private val _userData = MutableStateFlow(UserData())
    val userData: StateFlow<UserData> = _userData

    init {
        // Load data from DataStore on initialization
        viewModelScope.launch {
            context.dataStore.data.map { preferences ->
                UserData(
                    goal = preferences[KEY_GOAL] ?: "",
                    age = preferences[KEY_AGE] ?: 0,
                    weight = preferences[KEY_WEIGHT] ?: 0,
                    target = preferences[KEY_TARGET] ?: 0,
                    lifestyle = preferences[KEY_LIFESTYLE] ?: ""
                )
            }.collect { _userData.value = it }
        }
    }

    // Update functions for each attribute
    fun updateGoal(goal: String) {
        viewModelScope.launch {
            context.dataStore.edit { it[KEY_GOAL] = goal }
            _userData.value = _userData.value.copy(goal = goal)
        }
    }

    fun updateAge(age: Int) {
        viewModelScope.launch {
            context.dataStore.edit { it[KEY_AGE] = age }
            _userData.value = _userData.value.copy(age = age)
        }
    }

    fun updateWeight(weight: Int) {
        viewModelScope.launch {
            context.dataStore.edit { it[KEY_WEIGHT] = weight }
            _userData.value = _userData.value.copy(weight = weight)
        }
    }

    fun updateTarget(target: Int) {
        viewModelScope.launch {
            context.dataStore.edit { it[KEY_TARGET] = target }
            _userData.value = _userData.value.copy(target = target)
        }
    }

    fun updateLifestyle(lifestyle: String) {
        viewModelScope.launch {
            context.dataStore.edit { it[KEY_LIFESTYLE] = lifestyle }
            _userData.value = _userData.value.copy(lifestyle = lifestyle)
        }
    }
}
