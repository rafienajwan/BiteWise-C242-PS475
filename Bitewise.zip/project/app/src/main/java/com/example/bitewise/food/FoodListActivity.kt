package com.example.bitewise.food

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.bitewise.models.FoodItem
import com.example.bitewise.ui.theme.BitewiseTheme

class FoodListActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BitewiseTheme {
                val viewModel: FoodListViewModel = viewModel()
                FoodListScreen(viewModel, onFoodSelected = { food ->
                    val resultIntent = Intent().apply {
                        putExtra("selected_food", food)
                    }
                    setResult(Activity.RESULT_OK, resultIntent)
                    finish()
                })
            }
        }
    }
}

@Composable
fun FoodListScreen(viewModel: FoodListViewModel, onFoodSelected: (FoodItem) -> Unit) {
    val searchQuery by rememberSaveable { mutableStateOf(viewModel.searchQuery) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        BasicTextField(
            value = searchQuery,
            onValueChange = { viewModel.updateSearchQuery(it) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            decorationBox = { innerTextField ->
                if (searchQuery.isEmpty()) {
                    Text(text = "Search Food")
                }
                innerTextField()
            }
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(viewModel.filteredFoods) { food ->
                FoodListItem(food, onFoodSelected)
            }
        }
    }
}

@Composable
fun FoodListItem(food: FoodItem, onFoodSelected: (FoodItem) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clickable { onFoodSelected(food) },
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(text = food.name, style = MaterialTheme.typography.headlineSmall)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Calories: ${food.calories}")
            Text(text = "Proteins: ${food.proteins}g")
            Text(text = "Fats: ${food.fats}g")
            Text(text = "Carbs: ${food.carbs}g")
        }
    }
}

@Composable
@Preview(showBackground = true)
fun FoodListScreenPreview() {
    BitewiseTheme {
        val viewModel: FoodListViewModel = viewModel()
        FoodListScreen(viewModel, onFoodSelected = {})
    }
}
