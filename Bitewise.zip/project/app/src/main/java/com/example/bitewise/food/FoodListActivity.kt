package com.example.bitewise.food

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bitewise.models.FoodItem
import com.example.bitewise.ui.theme.BitewiseTheme

class FoodListActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BitewiseTheme {
                FoodListScreen { selectedFood, selectedGrams ->
                    val resultIntent = Intent().apply {
                        putExtra("SELECTED_FOOD_NAME", selectedFood.name)
                        putExtra("SELECTED_FOOD_CALORIES", (selectedFood.calories * selectedGrams / 100))
                        putExtra("SELECTED_FOOD_PROTEINS", (selectedFood.proteins * selectedGrams / 100))
                        putExtra("SELECTED_FOOD_FATS", (selectedFood.fats * selectedGrams / 100))
                        putExtra("SELECTED_FOOD_CARBS", (selectedFood.carbs * selectedGrams / 100))
                        putExtra("SELECTED_FOOD_QUANTITY", selectedGrams)
                    }
                    setResult(Activity.RESULT_OK, resultIntent)
                    finish()
                }
            }
        }
    }

    @Composable
    fun FoodListScreen(onFoodSelected: (FoodItem, Int) -> Unit) {
        var searchQuery by remember { mutableStateOf("") }
        val allFoods = remember { FoodModel().allFoods }
        val filteredFoods by remember(searchQuery) {
            derivedStateOf {
                if (searchQuery.isEmpty()) {
                    allFoods
                } else {
                    allFoods.filter { food ->
                        food.name.contains(searchQuery, ignoreCase = true)
                    }
                }
            }
        }

        var selectedFood by remember { mutableStateOf<FoodItem?>(null) }
        var isDialogOpen by remember { mutableStateOf(false) }
        var inputGrams by remember { mutableStateOf("100") }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Search Food") },
                    navigationIcon = {
                        IconButton(onClick = { finish() }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    },
                    backgroundColor = Color(0xFF35CC8C),
                    contentColor = Color.White
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
            ) {
                TextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = { Text("Search Food") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                )

                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(filteredFoods) { food ->
                        FoodCard(food = food, onClick = {
                            selectedFood = food
                            isDialogOpen = true
                        })
                    }
                }

                if (isDialogOpen && selectedFood != null) {
                    AlertDialog(
                        onDismissRequest = { isDialogOpen = false },
                        title = { Text(text = selectedFood!!.name, fontWeight = FontWeight.Bold, fontSize = 20.sp) },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("${selectedFood!!.calories} Calories / 100g")
                                Text("${selectedFood!!.proteins}g Proteins / 100g")
                                Text("${selectedFood!!.fats}g Fats / 100g")
                                Text("${selectedFood!!.carbs}g Carbs / 100g")
                                Spacer(modifier = Modifier.height(16.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Amount: ", modifier = Modifier.padding(end = 8.dp))
                                    TextField(
                                        value = inputGrams,
                                        onValueChange = { inputGrams = it.filter { char -> char.isDigit() } },
                                        modifier = Modifier.width(80.dp),
                                        singleLine = true
                                    )
                                    Text(" grams")
                                }
                            }
                        },
                        confirmButton = {
                            Button(onClick = {
                                val grams = inputGrams.toIntOrNull() ?: 100
                                onFoodSelected(selectedFood!!, grams)
                                isDialogOpen = false
                            }) {
                                Text("OK")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { isDialogOpen = false }) {
                                Text("Cancel")
                            }
                        }
                    )
                }
            }
        }
    }

    @Composable
    fun FoodCard(food: FoodItem, onClick: () -> Unit) {
        Card(
            shape = MaterialTheme.shapes.medium,
            elevation = 4.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .clickable(onClick = onClick)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = food.name, style = MaterialTheme.typography.body1)
                Text(text = "${food.calories} Cal / 100g", style = MaterialTheme.typography.body2, color = Color.Gray)
            }
        }
    }
}
