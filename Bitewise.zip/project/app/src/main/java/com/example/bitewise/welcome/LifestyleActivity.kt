package com.example.bitewise.welcome

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bitewise.ui.theme.BitewiseTheme
import com.example.bitewise.user.UserViewModel

class LifestyleActivity : ComponentActivity() {
    private val userViewModel: UserViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BitewiseTheme {
                ActiveLevelScreen(
                    userViewModel = userViewModel,
                    onBackClick = {
                        startActivity(Intent(this, TargetPickActivity::class.java))
                        finish()
                    },
                    onNextClick = {
                        startActivity(Intent(this, NutritionPickActivity::class.java))
                        finish()
                    }
                )
            }
        }
    }
}

@Composable
fun ActiveLevelScreen(userViewModel: UserViewModel, onBackClick: () -> Unit, onNextClick: () -> Unit) {
    val userData by userViewModel.userData.collectAsState()
    var selectedLevel by remember { mutableStateOf(userData.lifestyle) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "How active are you?",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black
        )
        Text(
            text = "A sedentary person burns fewer calories than an active person.",
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(horizontal = 24.dp)
        )
        Spacer(modifier = Modifier.height(32.dp))
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
        ) {
            ActiveLevelOption("Sedentary", selectedLevel == "Sedentary") { selectedLevel = "Sedentary" }
            ActiveLevelOption("Lightly Active", selectedLevel == "Lightly Active") { selectedLevel = "Lightly Active" }
            ActiveLevelOption("Average", selectedLevel == "Average") { selectedLevel = "Average" }
            ActiveLevelOption("Moderately Active", selectedLevel == "Moderately Active") { selectedLevel = "Moderately Active" }
            ActiveLevelOption("Very Active", selectedLevel == "Very Active") { selectedLevel = "Very Active" }
        }
        Spacer(modifier = Modifier.height(32.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(onClick = onBackClick) {
                Text(text = "Back", color = MaterialTheme.colorScheme.onBackground)
            }
            if (selectedLevel.isNotEmpty()) {
                FloatingActionButton(
                    onClick = {
                        userViewModel.updateLifestyle(selectedLevel) // Simpan data ke ViewModel
                        onNextClick()
                    },
                    shape = CircleShape,
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White
                ) {
                    Icon(
                        imageVector = Icons.Filled.ArrowForward,
                        contentDescription = "Next"
                    )
                }
            }
        }
    }
}

@Composable
fun ActiveLevelOption(text: String, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp)
            .height(50.dp)
            .border(
                width = 2.dp,
                color = if (isSelected) Color.Green else Color.Transparent,
                shape = RoundedCornerShape(8.dp)
            )
            .background(
                color = Color.White,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            fontSize = 18.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onBackground
        )
    }
}
