package com.example.bitewise.recipe

class RecipeActivity {
}