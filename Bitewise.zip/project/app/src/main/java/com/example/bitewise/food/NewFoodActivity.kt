package com.example.bitewise.food

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bitewise.ui.theme.BitewiseTheme

class NewFoodActivity : ComponentActivity() {
    private val foodListLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val foodName = result.data?.getStringExtra("SELECTED_FOOD_NAME") ?: return@registerForActivityResult
            val foodCalories = result.data?.getIntExtra("SELECTED_FOOD_CALORIES", 0) ?: 0
            val foodProteins = result.data?.getIntExtra("SELECTED_FOOD_PROTEINS", 0) ?: 0
            val foodFats = result.data?.getIntExtra("SELECTED_FOOD_FATS", 0) ?: 0
            val foodCarbs = result.data?.getIntExtra("SELECTED_FOOD_CARBS", 0) ?: 0
            val foodQuantity = result.data?.getIntExtra("SELECTED_FOOD_QUANTITY", 100) ?: 100

            foodItems.add(FoodItem(foodName, foodQuantity, foodCalories, foodProteins, foodFats, foodCarbs))
        }
    }

    private val foodItems = mutableStateListOf<FoodItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BitewiseTheme {
                NewFoodScreen(
                    activity = this,
                    foodItems = foodItems,
                    onSaveMeal = { mealName, totalCalories, totalProteins, totalFats, totalCarbs ->
                        val resultIntent = Intent().apply {
                            putExtra("MEAL_NAME", mealName)
                            putExtra("MEAL_CALORIES", totalCalories)
                            putExtra("MEAL_PROTEINS", totalProteins)
                            putExtra("MEAL_FATS", totalFats)
                            putExtra("MEAL_CARBS", totalCarbs)
                        }
                        setResult(Activity.RESULT_OK, resultIntent)
                        finish()
                    },
                    onAddFood = {
                        val intent = Intent(this, FoodListActivity::class.java)
                        foodListLauncher.launch(intent)
                    }
                )
            }
        }
    }
}

@Composable
fun NewFoodScreen(
    activity: Activity,
    foodItems: MutableList<FoodItem>,
    onSaveMeal: (String, Int, Int, Int, Int) -> Unit,
    onAddFood: () -> Unit
) {
    var mealName by remember { mutableStateOf("Meal #1") }
    var isDialogOpen by remember { mutableStateOf(false) }

    if (isDialogOpen) {
        RenameDialog(
            initialName = mealName,
            onConfirm = { newName ->
                mealName = newName
                isDialogOpen = false
            },
            onDismiss = { isDialogOpen = false }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = mealName,
                            color = Color.Black,
                            fontSize = 18.sp,
                            modifier = Modifier.clickable { isDialogOpen = true }
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = "Edit Meal Name",
                            modifier = Modifier.clickable { isDialogOpen = true }
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { activity.finish() }) { // Tutup aktivitas
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                },
                actions = {
                    IconButton(onClick = onAddFood) {
                        Icon(Icons.Default.Add, contentDescription = "Add Food", tint = Color.Black)
                    }
                },
                backgroundColor = Color.White,
                elevation = 4.dp
            )
        },
        bottomBar = {
            Button(
                onClick = {
                    val totalCalories = foodItems.sumOf { it.calories }
                    val totalProteins = foodItems.sumOf { it.proteins }
                    val totalFats = foodItems.sumOf { it.fats }
                    val totalCarbs = foodItems.sumOf { it.carbs }

                    onSaveMeal(mealName, totalCalories, totalProteins, totalFats, totalCarbs)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF35CC8C))
            ) {
                Text("Save", color = Color.White, fontSize = 16.sp)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            NutrientSummaryRow(
                calories = foodItems.sumOf { it.calories },
                proteins = foodItems.sumOf { it.proteins },
                fats = foodItems.sumOf { it.fats },
                carbs = foodItems.sumOf { it.carbs }
            )

            if (foodItems.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No foods added yet", style = MaterialTheme.typography.body2)
                }
            } else {
                LazyColumn {
                    items(foodItems) { food ->
                        FoodCard(food = food, onDelete = { foodItems.remove(food) })
                    }
                }
            }
        }
    }
}

@Composable
    fun RenameDialog(
        initialName: String,
        onConfirm: (String) -> Unit,
        onDismiss: () -> Unit
    ) {
        var newName by remember { mutableStateOf(initialName) }
        val focusManager = LocalFocusManager.current

        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Rename Meal") },
            text = {
                TextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = {
                        Text(
                            text = "Meal Name",
                            color = Color(0xFF35CC8C)
                        )
                    },
                    colors = TextFieldDefaults.textFieldColors(
                        focusedIndicatorColor = Color(0xFF35CC8C),
                        cursorColor = Color(0xFF35CC8C),
                        unfocusedIndicatorColor = Color.LightGray,
                        textColor = Color.Black,
                        backgroundColor = Color.Transparent
                    ),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions.Default.copy(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            focusManager.clearFocus()
                            onConfirm(newName)
                        }
                    )
                )
            },
            confirmButton = {
                Button(onClick = { onConfirm(newName) },
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF35CC8C))
                ) {
                    Text("OK", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text("Cancel", color = Color(0xFF35CC8C))
                }
            }
        )
    }

    @Composable
    fun NutrientSummaryRow(calories: Int, proteins: Int, fats: Int, carbs: Int) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            NutrientCard("Calories", "$calories")
            NutrientCard("Proteins", "${proteins}g")
            NutrientCard("Fats", "${fats}g")
            NutrientCard("Carbs", "${carbs}g")
        }
    }

    @Composable
    fun NutrientCard(label: String, value: String) {
        Card(
            modifier = Modifier
                .padding(4.dp)
                .width(80.dp),
            elevation = 4.dp
        ) {
            Column(
                modifier = Modifier.padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(value, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(label, fontSize = 12.sp, color = Color.Gray)
            }
        }
    }

    @Composable
    fun FoodCard(food: FoodItem, onDelete: () -> Unit) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(food.name, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "${food.quantity} g • ${food.calories} Cal",
                        fontSize = 14.sp,
                        color = Color.Gray
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                }
            }
        }
    }

    data class FoodItem(
        val name: String,
        val quantity: Int,
        val calories: Int,
        val proteins: Int,
        val fats: Int,
        val carbs: Int
    )
