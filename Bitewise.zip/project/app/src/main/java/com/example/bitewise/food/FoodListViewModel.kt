package com.example.bitewise.food

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.bitewise.models.FoodItem

class FoodListViewModel : ViewModel() {
    var searchQuery by mutableStateOf("")
        private set

    private val allFoods: List<FoodItem> = listOf(
        FoodItem("Banana Smoothie", 110, 110, 2, 4, 18),
        FoodItem("Beef Burger", 250, 250, 15, 10, 25),
        FoodItem("Chicken Porridge", 120, 120, 7, 4, 14),
        FoodItem("Chicken Soup", 90, 90, 7, 4, 5),
        FoodItem("Chicken Satay", 225, 225, 15, 13, 4),
        FoodItem("Coffee with Milk", 60, 60, 1, 3, 5),
        FoodItem("Fried Noodles", 225, 225, 5, 9, 30),
        FoodItem("Fried Tempe", 140, 140, 8, 9, 5),
        FoodItem("Fried Tofu", 100, 100, 6, 5, 4),
        FoodItem("Fried Rice", 175, 175, 4, 8, 23),
        FoodItem("Grilled Chicken", 125, 125, 11, 6, 3),
        FoodItem("Grilled Fish", 150, 150, 13, 8, 3),
        FoodItem("Indonesian Salad (Gado-Gado)", 175, 175, 5, 10, 20),
        FoodItem("Margherita Pizza", 300, 300, 9, 13, 25),
        FoodItem("Stir-Fried Flat Noodles", 200, 200, 6, 9, 25),
        FoodItem("Sweet Dessert (Cendol)", 90, 90, 1, 2, 18),
        FoodItem("Toasted Bread", 90, 90, 3, 4, 15),
        FoodItem("Vegetable Salad", 60, 60, 2, 3, 10),
        FoodItem("Wheat Cereal", 115, 115, 4, 2, 23),
        FoodItem("White Rice", 130, 130, 2, 1, 30)
    )

    val filteredFoods: List<FoodItem>
        get() = allFoods.filter { food -> food.name.contains(searchQuery, ignoreCase = true) }

    fun updateSearchQuery(query: String) {
        searchQuery = query
    }
}
