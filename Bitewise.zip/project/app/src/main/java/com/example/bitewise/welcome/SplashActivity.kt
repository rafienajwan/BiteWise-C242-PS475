package com.example.bitewise.welcome

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.bitewise.R
import com.example.bitewise.ui.theme.BitewiseTheme

class SplashActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Setel status bar dan navigation bar ke warna default
        window.statusBarColor = Color.White.toArgb()
        window.navigationBarColor = Color.White.toArgb()

        setContent {
            BitewiseTheme {
                SplashScreen()
            }
        }

        // Delay untuk menampilkan SplashScreen selama beberapa detik
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, FirstActivity::class.java))
            finish()
        }, 2000) // 2000 milliseconds = 2 seconds
    }
}

@Composable
fun SplashScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.donut_image),
            contentDescription = "Logo Donat",
            modifier = Modifier.size(128.dp)
        )
    }
}
