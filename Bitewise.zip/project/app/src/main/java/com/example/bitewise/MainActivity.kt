package com.example.bitewise

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Settings
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bitewise.food.NewFoodActivity
import com.example.bitewise.setting.SettingActivity
import com.example.bitewise.ui.theme.BitewiseTheme

class MainActivity : ComponentActivity() {

    private lateinit var newFoodLauncher: ActivityResultLauncher<Intent>
    private val meals = mutableStateListOf<Meal>()

    data class Meal(
        val name: String,
        val calories: Int,
        val proteins: Int,
        val fats: Int,
        val carbs: Int
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize the ActivityResultLauncher
        newFoodLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val mealName = result.data?.getStringExtra("MEAL_NAME") ?: "Unknown"
                val mealCalories = result.data?.getIntExtra("MEAL_CALORIES", 0) ?: 0
                val mealProteins = result.data?.getIntExtra("MEAL_PROTEINS", 0) ?: 0
                val mealFats = result.data?.getIntExtra("MEAL_FATS", 0) ?: 0
                val mealCarbs = result.data?.getIntExtra("MEAL_CARBS", 0) ?: 0

                meals.add(Meal(mealName, mealCalories, mealProteins, mealFats, mealCarbs))
            }
        }

        setContent {
            BitewiseTheme {
                MainScreen(
                    onAddMeal = {
                        val intent = Intent(this, NewFoodActivity::class.java)
                        newFoodLauncher.launch(intent)
                    },
                    onSettingsClicked = {
                        startActivity(Intent(this, SettingActivity::class.java))
                    }
                )
            }
        }
    }

    @Composable
    fun MainScreen(onAddMeal: () -> Unit, onSettingsClicked: () -> Unit) {
        val scaffoldState = rememberScaffoldState()
        val waterMax = 3.0f
        var waterIntake by remember { mutableStateOf(0.0f) } // Water intake in liters

        Scaffold(
            scaffoldState = scaffoldState,
            topBar = {
                TopAppBar(
                    title = { Text("BiteWise", fontWeight = FontWeight.Bold) },
                    actions = {
                        IconButton(onClick = onSettingsClicked) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings")
                        }
                    },
                    backgroundColor = Color(0xFF35CC8C),
                    elevation = 4.dp
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = onAddMeal, backgroundColor = Color(0xFF35CC8C)) {
                    Icon(Icons.Default.Add, contentDescription = "Add Meal", tint = Color.White)
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
            ) {
                NutrientIndicators()
                Spacer(modifier = Modifier.height(16.dp))
                WaterTracker(
                    current = waterIntake,
                    max = waterMax,
                    onAdd = { if (waterIntake + 0.1f <= waterMax) waterIntake += 0.1f },
                    onRemove = { if (waterIntake - 0.1f >= 0f) waterIntake -= 0.1f }
                )
                Spacer(modifier = Modifier.height(16.dp))
                MealsSection(meals = meals, onAddMeal = onAddMeal, onDeleteMeal = { meal ->
                    meals.remove(meal)
                })
            }
        }
    }

    @Composable
    fun NutrientIndicators() {
        val totalProteins = meals.sumOf { it.proteins }
        val totalFats = meals.sumOf { it.fats }
        val totalCarbs = meals.sumOf { it.carbs }
        val totalCalories = meals.sumOf { it.calories }

        Column {
            NutrientIndicator("Proteins", totalProteins, 225, Color.Red)
            NutrientIndicator("Fats", totalFats, 118, Color.Yellow)
            NutrientIndicator("Carbs", totalCarbs, 340, Color.Green)
            NutrientIndicator("Calories", totalCalories, 3400, Color.Blue)
        }
    }

    @Composable
    fun NutrientIndicator(label: String, current: Int, max: Int, color: Color) {
        val progress = current.toFloat() / max
        Card(
            shape = MaterialTheme.shapes.medium,
            elevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = label, style = MaterialTheme.typography.body2)
                    Text(
                        text = "$current / $max",
                        style = MaterialTheme.typography.body2,
                        color = Color.Gray
                    )
                }
                LinearProgressIndicator(
                    progress = progress.coerceIn(0f, 1f),
                    color = color,
                    backgroundColor = Color.LightGray,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                )
            }
        }
    }

    @Composable
    fun WaterTracker(current: Float, max: Float, onAdd: () -> Unit, onRemove: () -> Unit) {
        val progress = current / max
        Card(
            shape = MaterialTheme.shapes.medium,
            elevation = 4.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Water Intake: ${String.format("%.1f", current)}L / ${String.format("%.1f", max)}L",
                    style = MaterialTheme.typography.body2
                )
                LinearProgressIndicator(
                    progress = progress.coerceIn(0f, 1f),
                    color = Color(0xFF00BCD4),
                    backgroundColor = Color.LightGray,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                )
                Row(
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                ) {
                    IconButton(onClick = onRemove) {
                        Icon(Icons.Default.Remove, contentDescription = "Decrease Water Intake")
                    }
                    IconButton(onClick = onAdd) {
                        Icon(Icons.Default.Add, contentDescription = "Increase Water Intake")
                    }
                }
            }
        }
    }

    @Composable
    fun MealsSection(meals: List<Meal>, onAddMeal: () -> Unit, onDeleteMeal: (Meal) -> Unit) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = "Meals", style = MaterialTheme.typography.h6)
            if (meals.isEmpty()) {
                Text(text = "No meals added yet.", style = MaterialTheme.typography.body2)
            } else {
                LazyColumn {
                    items(meals) { meal ->
                        MealCard(meal = meal, onDeleteMeal = onDeleteMeal)
                    }
                }
            }
        }
    }

    @Composable
    fun MealCard(meal: Meal, onDeleteMeal: (Meal) -> Unit) {
        Card(
            shape = MaterialTheme.shapes.medium,
            elevation = 4.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = meal.name, style = MaterialTheme.typography.body1)
                Row {
                    Text(text = "${meal.calories} Cal", style = MaterialTheme.typography.body2)
                    IconButton(onClick = { onDeleteMeal(meal) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete Meal", tint = Color.Red)
                    }
                }
            }
        }
    }
}
