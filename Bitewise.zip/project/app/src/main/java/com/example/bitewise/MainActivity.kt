package com.example.bitewise

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.BottomNavigationItem
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bitewise.food.NewFoodActivity
import com.example.bitewise.ui.theme.BitewiseTheme
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BitewiseTheme {
                val drawerState = rememberDrawerState(DrawerValue.Closed)
                val scope = rememberCoroutineScope()

                SideNavigationDrawer(
                    drawerState = drawerState,
                    onDrawerClosed = {
                        scope.launch { drawerState.close() }
                    },
                    onMenuClicked = {
                        scope.launch { drawerState.open() }
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomToolbar(onMenuClicked: () -> Unit) {
    TopAppBar(
        title = { Text("Today", color = Color.White, fontSize = 18.sp) }, // Decreased font size
        navigationIcon = {
            IconButton(onClick = onMenuClicked) {
                Icon(AppIcons.Menu, contentDescription = "Menu", tint = Color.White)
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color(0xFF35CC8C), // Changed color to green
            titleContentColor = Color.White,
            actionIconContentColor = Color.White,
            navigationIconContentColor = Color.White
        )
    )
}

@Composable
fun NutrientsCard(title: String, amount: String, target: String, cardColor: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier
            .padding(4.dp) // Decreased padding
            .height(100.dp), // Decreased height
        shape = RoundedCornerShape(8.dp), // Decreased corner radius
        colors = CardDefaults.cardColors(containerColor = cardColor)
    ) {
        Column(
            modifier = Modifier.padding(8.dp), // Decreased padding
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 14.sp, // Decreased font size
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp)) // Decreased height
            Text(
                text = "$amount / $target",
                color = Color.White,
                fontSize = 12.sp // Decreased font size
            )
        }
    }
}

@Composable
fun WaterCard(amount: String, percentage: Int, cardColor: Color, onIncrement: () -> Unit, onDecrement: () -> Unit) {
    Card(
        modifier = Modifier
            .padding(4.dp) // Decreased padding
            .height(100.dp), // Decreased height
        shape = RoundedCornerShape(8.dp), // Decreased corner radius
        colors = CardDefaults.cardColors(containerColor = cardColor)
    ) {
        Column(
            modifier = Modifier.padding(8.dp), // Decreased padding
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = "Water Intake",
                color = Color.White,
                fontSize = 14.sp, // Decreased font size
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp)) // Decreased height
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDecrement) {
                    Icon(AppIcons.Remove, contentDescription = "Decrement", tint = Color.White)
                }
                Text(
                    text = amount,
                    color = Color.White,
                    fontSize = 12.sp // Decreased font size
                )
                IconButton(onClick = onIncrement) {
                    Icon(AppIcons.Add, contentDescription = "Increment", tint = Color.White)
                }
            }
            LinearProgressIndicator(
                progress = percentage / 100f,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = Color.Cyan,
                trackColor = Color.Gray
            )
        }
    }
}

@Composable
fun MealCard(meal: String, calories: String, cardColor: Color) {
    Card(
        modifier = Modifier
            .padding(4.dp) // Decreased padding
            .height(80.dp) // Decreased height
            .fillMaxWidth(),
        shape = RoundedCornerShape(8.dp), // Decreased corner radius
        colors = CardDefaults.cardColors(containerColor = cardColor)
    ) {
        Column(
            modifier = Modifier.padding(8.dp), // Decreased padding
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = meal,
                color = Color.White,
                fontSize = 14.sp, // Decreased font size
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp)) // Decreased height
            Text(
                text = "$calories Cal",
                color = Color.White,
                fontSize = 12.sp // Decreased font size
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SideNavigationDrawer(drawerState: DrawerState, onDrawerClosed: () -> Unit, onMenuClicked: () -> Unit) {
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    text = "Settings",
                    modifier = Modifier
                        .padding(16.dp)
                        .clickable { /* Navigate to SettingsActivity */ }
                )
                Text(
                    text = "Contact Us",
                    modifier = Modifier
                        .padding(16.dp)
                        .clickable { /* Navigate to ContactActivity */ }
                )
                Text(
                    text = "About App",
                    modifier = Modifier
                        .padding(16.dp)
                        .clickable { /* Navigate to AboutActivity */ }
                )
            }
        },
        content = {
            MainScreen(onMenuClicked)
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(onMenuClicked: () -> Unit) {
    val context = LocalContext.current // Move context here
    var waterIntake by remember { mutableStateOf(1.9f) }
    val maxWaterIntake = 2.5f
    val waterPercentage = (waterIntake / maxWaterIntake * 100).toInt()

    // Fix water intake decrement issue by rounding the values
    waterIntake = (waterIntake * 10).roundToInt() / 10f

    Scaffold(
        topBar = {
            CustomToolbar(onMenuClicked = onMenuClicked)
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                // Navigate to NewFoodActivity
                context.startActivity(Intent(context, NewFoodActivity::class.java))
            }) {
                Icon(AppIcons.Add, contentDescription = "Meals")
            }
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .padding(paddingValues)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()) // Enable vertical scrolling
                    .fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    NutrientsCard(
                        title = "Proteins",
                        amount = "150g",
                        target = "225g",
                        cardColor = Color(0xFF66BB6A),
                        modifier = Modifier.weight(1f)
                    )
                    NutrientsCard(
                        title = "Fats",
                        amount = "30g",
                        target = "118g",
                        cardColor = Color(0xFFEF5350),
                        modifier = Modifier.weight(1f)
                    )
                    NutrientsCard(
                        title = "Carbs",
                        amount = "319g",
                        target = "340g",
                        cardColor = Color(0xFF42A5F5),
                        modifier = Modifier.weight(1f)
                    )
                }
                NutrientsCard(
                    title = "Calories",
                    amount = "2456",
                    target = "3400",
                    cardColor = Color(0xFFFFA726)
                )
                WaterCard(
                    amount = "${waterIntake}L / ${maxWaterIntake}L",
                    percentage = waterPercentage,
                    cardColor = Color(0xFF42A5F5),
                    onIncrement = {
                        if (waterIntake < maxWaterIntake) {
                            waterIntake += 0.1f
                        }
                    },
                    onDecrement = {
                        if (waterIntake > 0) {
                            waterIntake -= 0.1f
                        }
                    }
                )
                MealCard(
                    meal = "Breakfast",
                    calories = "531",
                    cardColor = Color(0xFFAB47BC)
                )
                MealCard(
                    meal = "Lunch",
                    calories = "1024",
                    cardColor = Color(0xFFFF7043)
                )
            }
        },
        bottomBar = {
            BottomAppBar(
                containerColor = Color(0xFF35CC8C), // Changed color to green
                contentColor = Color.White
            ) {
                BottomNavigationItem(
                    icon = { Icon(AppIcons.Book, contentDescription = "Diary") },
                    label = { Text("Diary") },
                    selected = false,
                    onClick = { /* Handle Diary Click */ },
                    alwaysShowLabel = true
                )
                Spacer(modifier = Modifier.weight(1f, true)) // Spacer to push Recipe icon to the end
                BottomNavigationItem(
                    icon = { Icon(AppIcons.Star, contentDescription = "Recipe") },
                    label = { Text("Recipe") },
                    selected = false,
                    onClick = { /* Handle Recipe Click */ },
                    alwaysShowLabel = true
                )
            }
        }
    )
}

@Composable
@Preview(showBackground = true)
fun MainScreenPreview() {
    BitewiseTheme {
        MainScreen(onMenuClicked = { /* Do nothing in preview */ })
    }
}
