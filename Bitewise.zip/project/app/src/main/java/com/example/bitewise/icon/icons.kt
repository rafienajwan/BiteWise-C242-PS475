package com.example.bitewise

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material.icons.outlined.Book

object AppIcons {
    val Menu = Icons.Filled.Menu
    val Add = Icons.Filled.Add
    val Remove = Icons.Outlined.Remove
    val Book = Icons.Outlined.Book
    val Star = Icons.Filled.Star
}
