package com.example.bitewise.user

data class UserData(
    var goal: String = "",
    var gender: String = "",
    var age: Int = 0,
    var height: Int = 0,
    var weight: Int = 0,
    var target: Int = 0,
    var lifestyle: String = ""
)
