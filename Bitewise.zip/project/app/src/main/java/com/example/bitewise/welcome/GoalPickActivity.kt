package com.example.bitewise.welcome

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bitewise.user.UserViewModel
import com.example.bitewise.ui.theme.BitewiseTheme

class GoalPickActivity : ComponentActivity() {
    private val userViewModel: UserViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BitewiseTheme {
                GoalPickScreen(
                    userViewModel = userViewModel,
                    onNextClick = {
                        // Lanjut ke GenderPickActivity
                        startActivity(Intent(this, GenderPickActivity::class.java))
                        finish()
                    }
                )
            }
        }
    }
}

@Composable
fun GoalPickScreen(userViewModel: UserViewModel, onNextClick: () -> Unit) {
    // Konversi StateFlow menjadi State untuk digunakan di Compose
    val userData by userViewModel.userData.collectAsState()

    // State lokal untuk goal yang dipilih
    var selectedGoal by remember { mutableStateOf(userData.goal) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "What's your goal?",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black
        )
        Text(
            text = "We will calculate daily calories according to your goal.",
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(horizontal = 24.dp)
        )
        Spacer(modifier = Modifier.height(32.dp))
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
        ) {
            GoalOption(
                text = "Lose weight",
                isSelected = selectedGoal == "Lose weight",
                onClick = { selectedGoal = "Lose weight" }
            )
            GoalOption(
                text = "Maintain weight",
                isSelected = selectedGoal == "Maintain weight",
                onClick = { selectedGoal = "Maintain weight" }
            )
            GoalOption(
                text = "Gain weight",
                isSelected = selectedGoal == "Gain weight",
                onClick = { selectedGoal = "Gain weight" }
            )
        }
        Spacer(modifier = Modifier.height(32.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            horizontalArrangement = Arrangement.End
        ) {
            if (selectedGoal.isNotEmpty()) {
                FloatingActionButton(
                    onClick = {
                        userViewModel.updateGoal(selectedGoal)
                        onNextClick()
                    },
                    shape = RoundedCornerShape(50),
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White
                ) {
                    Icon(
                        imageVector = Icons.Filled.ArrowForward,
                        contentDescription = "Next"
                    )
                }
            }
        }
    }
}

@Composable
fun GoalOption(text: String, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp)
            .height(50.dp)
            .border(
                width = 2.dp,
                color = if (isSelected) Color.Green else Color.Transparent,
                shape = RoundedCornerShape(8.dp)
            )
            .background(
                color = Color.White,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            fontSize = 18.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onBackground
        )
    }
}
